<?php
class M_sekolah extends CI_Model
{
    public function simpan_data_sekolah($a)
    {
        $this->db->insert('sekolah_tb', $a);
    }

    public function getSekolah()
    {
        return $this->db->get('sekolah_tb')->result();
    }

    public function getDetailSekolah($id)
    {
        return  $this->db->get_where('sekolah_tb', array('id_sekolah' => $id))->row();
    }

    public function simpan_data_pondasi($a)
    {
        $this->db->insert('pondasi_tb', $a);
    }

    public function simpan_data_kolom($a)
    {
        $this->db->insert('kolom_tb', $a);
    }

    public function simpan_data_balok($a)
    {
        $this->db->insert('balok_tb', $a);
    }

    public function simpan_data_atap($a)
    {
        $this->db->insert('atap_tb', $a);
    }

    public function simpan_data_dinding($a)
    {
        $this->db->insert('dinding_tb', $a);
    }

    public function simpan_data_plafond($a)
    {
        $this->db->insert('plafond_tb', $a);
    }

    public function simpan_data_lantai($a)
    {
        $this->db->insert('lantai_tb', $a);
    }

    public function simpan_data_kusen($a)
    {
        $this->db->insert('kusen_tb', $a);
    }

    public function simpan_data_pintu($a)
    {
        $this->db->insert('pintu_tb', $a);
    }


    public function simpan_data_jendela($a)
    {
        $this->db->insert('jendela_tb', $a);
    }

    public function simpan_data_finishing_plafond($a)
    {
        $this->db->insert('finishing_plafond_tb', $a);
    }

    public function simpan_data_finishing_dinding($a)
    {
        $this->db->insert('finishing_dinding_tb', $a);
    }

    public function simpan_data_finishing_kusen($a)
    {
        $this->db->insert('finishing_kusen_tb', $a);
    }

    public function simpan_data_instalasi_listrik($a)
    {
        $this->db->insert('instalasi_listrik_tb', $a);
    }

    public function simpan_data_instalasi_air($a)
    {
        $this->db->insert('instalasi_air_tb', $a);
    }
}
