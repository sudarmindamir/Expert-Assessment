<!-- PERCOBAAN PERTAMA -->
<!-- <nav>
    <div class="nav nav-tabs" id="nav-tab" role="tablist">
        <a class="nav-link active" id="nav-home-tab" data-toggle="tab" href="nav-home" role="tab" aria-controls="nav-home" aria-selected="true">Penutup Atap</a>
        <a class="nav-link" id="nav-profile-tab" data-toggle="tab" href="nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false">Rangka Atap</a>
        <a class="nav-link" id="nav-contact-tab" data-toggle="tab" href="nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false">Contact</a>
    </div>
</nav>
<div class="tab-content" id="nav-tabContent">
    <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
        <p>Halooooooooooo fdknfd</p>
        <p>haloooooo</p>
    </div>

    <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
        <p>1232131231231231313133</p>
    </div>

    <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">
        <h1>dfndkfkfdfa</h1>
    </div>
</div> -->


<!-- PERCOBAAN KEDUA -->
<!-- <ul class="nav nav-tabs">

    <li class="nav-item">
        <a class="nav-link active" id="nav-datasekolah" href="nav-datasekolah">Data Sekolah</a>
        <div class="penutupatap">
            <form class="container">
                <div class="form-group">
                    <label for="exampleInputEmail1">Nama Sekolah</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">

                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Alamat</label>
                    <input type="password" class="form-control" id="exampleInputPassword1">
                </div>
                <div class="form-group form-check">

                </div>
                <button type="submit" class="btn btn-primary">Selanjutnya</button>
            </form>
        </div>
    </li>

    <li class="nav-item">
        <a class="nav-link" id="nav-rangkaatap" href="nav-rangkaatap">Penutup Atap</a>
        <div class="gambar">
            <img width="500" src="<?= base_url('assets/img/1.jpg') ?>">
        </div>
        <div class="container">
            <div class="mb-3">
                <label for="formGroupExampleInput" class="form-label">Panjang "a"</label>
                <input type="text" class="form-control" id="formGroupExampleInput" placeholder="">
            </div>
            <div class="mb-3">
                <label for="formGroupExampleInput2" class="form-label">Panjang "b"</label>
                <input type="text" class="form-control" id="formGroupExampleInput2" placeholder="">
            </div>
            <div class="mb-3">
                <label for="formGroupExampleInput3" class="form-label">Panjang "c"</label>
                <input type="text" class="form-control" id="formGroupExampleInput3" placeholder="">
            </div>
            <div class="mb-3">
                <label for="formGroupExampleInput4" class="form-label">Panjang "d"</label>
                <input type="text" class="form-control" id="formGroupExampleInput4" placeholder="">
            </div>
            <div class="mb-3">
                <label for="formGroupExampleInput5" class="form-label">Panjang "e"</label>
                <input type="text" class="form-control" id="formGroupExampleInput5" placeholder="">
            </div>
            <div class="mb-3">
                <label for="formGroupExampleInput6" class="form-label">Panjang "f"</label>
                <input type="text" class="form-control" id="formGroupExampleInput6" placeholder="">
            </div>
            <div class="button">
                <div class="row">
                    <div class="col">
                        <button type="submit" class="btn btn-primary">Kembali</button>
                    </div>
                    <div class="col">
                        <button type="submit" class="btn btn-primary">Selanjutnya</button>
                    </div>
                </div>
            </div>
        </div>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="#">Rangka Atap</a>
        <div class="gambar">
            <img width="500" src="<?= base_url('assets/img/1.jpg') ?>">
        </div>
        <div class="container">
            <div class="mb-3">
                <label for="formGroupExampleInput" class="form-label">Panjang "a"</label>
                <input type="text" class="form-control" id="formGroupExampleInput" placeholder="">
            </div>
            <div class="mb-3">
                <label for="formGroupExampleInput2" class="form-label">Panjang "b"</label>
                <input type="text" class="form-control" id="formGroupExampleInput2" placeholder="">
            </div>
            <div class="mb-3">
                <label for="formGroupExampleInput3" class="form-label">Panjang "c"</label>
                <input type="text" class="form-control" id="formGroupExampleInput3" placeholder="">
            </div>
            <div class="mb-3">
                <label for="formGroupExampleInput4" class="form-label">Panjang "d"</label>
                <input type="text" class="form-control" id="formGroupExampleInput4" placeholder="">
            </div>
            <div class="mb-3">
                <label for="formGroupExampleInput5" class="form-label">Panjang "e"</label>
                <input type="text" class="form-control" id="formGroupExampleInput5" placeholder="">
            </div>
            <div class="mb-3">
                <label for="formGroupExampleInput6" class="form-label">Panjang "f"</label>
                <input type="text" class="form-control" id="formGroupExampleInput6" placeholder="">
            </div>

            <div class="mb-3">
                <label for="formGroupExampleInput6" class="form-label">Luas "C"</label>
                <input type="text" class="form-control" id="formGroupExampleInput6" placeholder="">
            </div>
            <div class="button">
                <div class="row">
                    <div class="col">
                        <button type="submit" class="btn btn-primary">Kembali</button>
                    </div>
                    <div class="col">
                        <button type="submit" class="btn btn-primary">Selanjutnya</button>
                    </div>
                </div>
            </div>
        </div>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="#">Rangka Plafond</a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="#">Penutup Plafond</a>
    </li>

</ul> -->

<!-- PERCOBAAN KETIGA -->

<!-- <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">Home</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Profile</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" type="button" role="tab" aria-controls="contact" aria-selected="false">Contact</button>
        </li>
    </ul>
    <div class="tab-content" id="myTabContent">
        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">...</div>
        <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">...</div>
        <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">...</div>
    </div> -->




<!-- PERCOBAAN EMPAT -->
<div class="col-xs-10 col-sm-10 col-md-10 col-lg-10 col-xl10">
    <br />
    <ul class="nav nav-tabs">
        <li class="nav-item">
            <a href="#datasekolah" class="nav-link active" role="tab" data-toggle="tab">Data Sekolah</a>
        </li>

        <li class="nav-item">
            <a href="#pondasi" class="nav-link" role="tab" data-toggle="tab">Pondasi & Sloof</a>
        </li>

        <li class="nav-item">
            <a href="#kolom" class="nav-link" role="tab" data-toggle="tab">Kolom</a>
        </li>

        <li class="nav-item">
            <a href="#balok" class="nav-link" role="tab" data-toggle="tab">Balok</a>
        </li>

        <li class="nav-item">
            <a href="#atap" class="nav-link" role="tab" data-toggle="tab">Atap</a>
        </li>

        <li class="nav-item">
            <a href="#dinding" class="nav-link" role="tab" data-toggle="tab">Dinding</a>
        </li>

        <li class="nav-item">
            <a href="#plafond" class="nav-link" role="tab" data-toggle="tab">Plafond</a>
        </li>

        <li class="nav-item">
            <a href="#lantai" class="nav-link" role="tab" data-toggle="tab">Lantai</a>
        </li>

        <li class="nav-item">
            <a href="#kusen" class="nav-link" role="tab" data-toggle="tab">Kusen</a>
        </li>

        <li class="nav-item">
            <a href="#pintu" class="nav-link" role="tab" data-toggle="tab">Pintu</a>
        </li>

        <li class="nav-item">
            <a href="#jendela" class="nav-link" role="tab" data-toggle="tab">Jendela</a>
        </li>

        <li class="nav-item">
            <a href="#fplafond" class="nav-link" role="tab" data-toggle="tab">Finishing Plafond</a>
        </li>

        <li class="nav-item">
            <a href="#fdinding" class="nav-link" role="tab" data-toggle="tab">Finishing Dinding</a>
        </li>

        <li class="nav-item">
            <a href="#fkusen" class="nav-link" role="tab" data-toggle="tab">Finishing Kusen</a>
        </li>

        <li class="nav-item">
            <a href="#instalasilistrik" class="nav-link" role="tab" data-toggle="tab">Instalasi Listrik</a>
        </li>

        <li class="nav-item">
            <a href="#instalasiair" class="nav-link" role="tab" data-toggle="tab">Instalasi Air</a>
        </li>
        <!-- <li class="nav-item">
            <a href="#drainaselimbah" class="nav-link" role="tab" data-toggle="tab">Drainase Limbah</a>
        </li> -->
    </ul>

    <!-- isi konten dari tiap nav -->
    <div class="tab-content" id="myTabContent">

        <!--1. Data Sekolah --------------------------------------------------------------------------------------------------------------------------------->
        <div role="tabpanel" class="tab-pane active" id="datasekolah">
            <div class="container">
                <form action="<?= base_url('C_Sekolah/terimaData') ?>" method="POST">
                    <div class="mb-3">
                        <label for="formGroupExampleInput" class="form-label">Nama Sekolah</label>
                        <input type="text" class="form-control" name="nama_sekolah">
                    </div>
                    <div class="mb-3">
                        <label for="formGroupExampleInput2" class="form-label">Alamat Sekolah</label>
                        <input type="text" class="form-control" name="alamat_sekolah">
                    </div>
                    <div class="mb-3">
                        <label for="formGroupExampleInput2" class="form-label">Kabupaten/Kota</label>
                        <input type="text" class="form-control" name="kabupaten">
                    </div>
                    <div class="mb-3">
                        <label for="formGroupExampleInput2" class="form-label">Luas Bangunan</label>
                        <input type="text" class="form-control" name="luas_bangunan">
                    </div>
                    <div>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <!-- <a href="#pondasi" class="nav-link" role="tab" data-toggle="tab"></a> -->
                    </div>
                </form>
            </div>
        </div>

        <!-- 2.0 Pondasi dan Sloof ---------------------------------------------------------------------------------------------------------------------------------->
        <div role="tabpanel" class="tab-pane" id="pondasi">
            <div class="container">
                <!-- <img width="500" src="<?= base_url('assets/img/balok1.jpg') ?>"> -->
                <form action="<?= base_url('C_Sekolah/terimaDataPondasi') ?>" method="POST">
                    <form>
                        <div class="mb-3 form-check">
                            <input type="radio" value="0" class="form-check-input" name="pondasi">
                            <label class="form-check-label" for="exampleCheck1"> Pondasi diindikasikan dalam kondisi baik

                            </label>
                        </div>

                        <div class="mb-3 form-check">
                            <input type="radio" value="0.2" class="form-check-input" name="pondasi">
                            <label class="form-check-label" for="exampleCheck1">
                                Penurunan merata pada seluruh struktur
                                bangunan
                            </label>
                        </div>

                        <div class="mb-3 form-check">
                            <input type="radio" value="0.35" class="form-check-input" name="pondasi">
                            <label class="form-check-label" for="exampleCheck1"> Penurunan tidak merata namun perbedaan
                                penurunan tidak melebihi 1/250 L
                            </label>
                        </div>

                        <div class="mb-3 form-check">
                            <input type="radio" value="0.5" class="form-check-input" name="pondasi">
                            <label class="form-check-label" for="exampleCheck1"> Penurunan > 1/250 L sehingga
                                menimbulkan kerusakan atasnya.
                                Tanah
                                disekeliling bangunan naik
                            </label>
                        </div>

                        <div class="mb-3 form-check">
                            <input type="radio" value="0.7" class="form-check-input" name="pondasi">
                            <label class="form-check-label" for="exampleCheck1"> • Bangunan miring secara kasat mata
                                • Lantai dasar naik/menggelembung
                            </label>
                        </div>

                        <div class="mb-3 form-check">
                            <input type="radio" value="0.85" class="form-check-input" name="pondasi">
                            <label class="form-check-label" for="exampleCheck1"> Pondasi patah, bergeser akibat longsor,
                                struktur atas menjadi rusak
                            </label>
                        </div>

                        <div class="mb-3 form-check">
                            <input type="radio" value="1" class="form-check-input" name="pondasi">
                            <label class="form-check-label" for="exampleCheck1">Material Dimensi dan kontruksi pondasi diindikasikan tidak sesuai dengan persyaratan teknis merujuk pada rencana teknis apabila ada petunjuk teknis dan/atau SNI</label>
                        </div>


                        <a href="#kolom"> <button type="submit" class="btn btn-primary">Submit</button></a>

                    </form>
                </form>
            </div>
        </div>

        <!-- 2.1 Kolom ---------------------------------------------------------------------------------------------------------------------------------->
        <div role="tabpanel" class="tab-pane" id="kolom">
            <div class="container">
                <img width="500" src="<?= base_url('assets/img/balok1.jpg') ?>">
                <form action="<?= base_url('C_Sekolah/terimaDataKolom') ?>" method="POST">

                    <div class="mt-4 jumlah_unit">
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah Unit</label>
                            <input type="text" class="form-control" name="jumlah_unit">
                        </div>
                        <!-- <hr class="sidebar-divider my-0"> -->
                    </div>
                    <div class="mt-4 tidak_rusak">
                        <ul>
                            <!-- Deskripsi Kerusakan -->
                            <li>Kolom dalam kondisi baik</li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="tidak_rusak">
                        </div>
                    </div>
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class="mt-4 rusak_sangat_ringan">
                        <ul>
                            <li>Sudut kolom pecah</li>
                            <li>Plesteran kolom retak rambut</li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="rusak_sangat_ringan">
                        </div>
                    </div>
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class="mt-4 rusak_ringan">
                        <ul>
                            <li>Retak pada permukaan kolom, lebar retak
                                0.2mm-1.0mm</li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="rusak_ringan">
                        </div>
                    </div>
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class=" mt-4 rusak_sedang">
                        <ul>
                            <li>Retak pada permukaan kolom, lebar retak > 1.0
                                mm</li>
                            <li>Selimut beton gembur, beberapa tulangan
                                terlihat</li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="rusak_sedang">
                        </div>
                    </div>

                    <div class="rusak_berat">
                        <ul>
                            <li>Tulangan kolom terlihat 4 sisi pada 1 titik</li>
                            <li>Selimut beton hancur pada beberapa titik</li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="rusak_berat">
                        </div>
                    </div>

                    <div class="rusak_sangat_berat">
                        <ul>
                            <li>Beton inti kolom hancur, baja tulangan tertekuk</li>
                            <li>kolom patah</li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="rusak_sangat_berat">
                        </div>
                    </div>

                    <div class="komponen_tidak_sesuai">
                        <ul>
                            <li>Material Dimensi dan kontruksi pondasi diindikasikan tidak sesuai dengan persyaratan teknis merujuk pada rencana teknis apabila ada petunjuk teknis dan/atau SNI</li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="komponen_tidak-sesuai">
                        </div>
                    </div>

                    <div class="mb-5">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <!-- <a href="#penutupatap" class="nav-link" role="tab" data-toggle="tab"></a> -->
                    </div>
                </form>
            </div>
        </div>

        <!-- 3. Balok ------------------------------------------------------------------------------------------------------------------------------->
        <div role="tabpanel" class="tab-pane" id="balok">
            <div class="container">
                <img width="500" src="<?= base_url('assets/img/kolom1.jpg') ?>">
                <form action="<?= base_url('C_Sekolah/terimaDataBalok') ?>" method="POST">

                    <div class="mt-4 jumlah_unit">
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah Unit</label>
                            <input type="text" class="form-control" name="jumlah_unit">
                        </div>
                        <!-- <hr class="sidebar-divider my-0"> -->
                    </div>
                    <div class="mt-4 tidak_rusak">
                        <ul>
                            <!-- Deskripsi Kerusakan -->
                            <li>Balok dalam kondisi baik</li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="tidak_rusak">
                        </div>
                    </div>
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class="mt-4 rusak_sangat_ringan">
                        <ul>
                            <li>Retak 0.2 – 1.0 mm, retakan pada tengah bentang plat </li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="rusak_sangat_ringan">
                        </div>
                    </div>
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class="mt-4 rusak_ringan">
                        <ul>
                            <li>Retak 0.2 – 1.0 mm, retakan pada tengah bentang plat </li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="rusak_ringan">
                        </div>
                    </div>
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class=" mt-4 rusak_sedang">
                        <ul>
                            <li>Balok melendut, lebar retak > 1.0 mm</li>
                            <li>SRetak meluas pada beberapa tempat</li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="rusak_sedang">
                        </div>
                    </div>

                    <div class="rusak_berat">
                        <ul>
                            <li>Balok melendut, selimut beton hancur, tulangan terlihat</li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="rusak_berat">
                        </div>
                    </div>

                    <div class="rusak_sangat_berat">
                        <ul>
                            <li>Balok patah/runtuh</li>
                            <li>Plat dan balok lain yang menumpu pada balok
                                tersebut ikut rusa</li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="rusak_sangat_berat">
                        </div>
                    </div>

                    <div class="komponen_tidak_sesuai">
                        <ul>
                            <li>Material Dimensi dan kontruksi pondasi diindikasikan tidak sesuai dengan persyaratan teknis merujuk pada rencana teknis apabila ada petunjuk teknis dan/atau SNI</li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="komponen_tidak-sesuai">
                        </div>
                    </div>

                    <div class="mb-5">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <!-- <a href="#penutupatap" class="nav-link" role="tab" data-toggle="tab"></a> -->
                    </div>
                </form>
            </div>
        </div>
        <!-- akhir balok -->

        <!-- 4.Atap ------------------------------------------------------------------------------------------------------------------------------->
        <div role="tabpanel" class="tab-pane" id="atap">
            <div class="container">
                <img width="500" src="<?= base_url('assets/img/2.jpg') ?>">
                <form action="<?= base_url('C_Sekolah/terimaDataAtap') ?>" method="POST">

                    <div class="mt-4 Luas_A">
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas A</label>
                            <input type="text" class="form-control" name="luas_A">
                        </div>
                    </div>
                    <div class="mt-4 Luas_B">
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas B</label>
                            <input type="text" class="form-control" name="luas_B">
                        </div>
                    </div>


                    <!-- <div class="mt-4 tidak_rusak">
                        <ul>
                        
                            <li>Rangka Atap dalam kondisi baik
                            </li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas bidang yang rusak</label>
                            <input type="text" class="form-control" name="tidak_rusak">
                        </div>
                    </div> -->

                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class="mt-4 rusak_sangat_ringan">
                        <ul>
                            <li>Karat rangka mulai terlihat, gording melendut </li>
                            <li>Perubahan warna pada sebagian lapisan warna penutup atap </li>
                            <li>Genteng terlepas dari dudukannya </li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas bidang yang rusak</label>
                            <input type="text" class="form-control" name="rusak_sangat_ringan">
                        </div>
                    </div>
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class="mt-4 rusak_ringan">
                        <ul>
                            <li>Karat rangka meluas, konstruksi bergetar akibat angin </li>
                            <li>Reng rusak, kaso-kaso rusak Genteng retak dan terdapat
                                bocoran terbatas </li>
                            <li>Perubahan warna pada lapisan cat meluas </li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas bidang yang rusak</label>
                            <input type="text" class="form-control" name="rusak_ringan">
                        </div>
                    </div>
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class=" mt-4 rusak_sedang">
                        <ul>
                            <li>Struktur atap melendut, flens profil sobek, retak pada
                                sambungan las</li>
                            <li>Gording/rangka plafond melendut Bocoran meluas</li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas bidang yang rusak</label>
                            <input type="text" class="form-control" name="rusak_sedang">
                        </div>
                    </div>

                    <div class="rusak_berat">
                        <ul>
                            <li>Baut penyambung dan plat sambungan bengkok, profil
                                tertekuk, korasi meluas di banyak tempat</li>
                            <li>Penutup atap melendut sangat besar dengan
                                kemungkinan keruntuhan besar</li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas bidang yang rusak</label>
                            <input type="text" class="form-control" name="rusak_berat">
                        </div>
                    </div>

                    <div class="rusak_sangat_berat">
                        <ul>
                            <li>Rangka atap runtuh</li>
                            <li>omponen struktur tertekuk</li>
                            <li>Sambungan putus, profil tertekukl, konstruksi runtuh</li>


                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas bidang yang rusak</label>
                            <input type="text" class="form-control" name="rusak_sangat_berat">
                        </div>
                    </div>

                    <div class="komponen_tidak_sesuai">
                        <ul>
                            <li>Material Dimensi dan kontruksi pondasi diindikasikan tidak sesuai dengan persyaratan teknis merujuk pada rencana teknis apabila ada petunjuk teknis dan/atau SNI</li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas bidang yang rusak</label>
                            <input type="text" class="form-control" name="komponen_tidak-sesuai">
                        </div>
                    </div>

                    <div class="mb-5">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <!-- <a href="#penutupatap" class="nav-link" role="tab" data-toggle="tab"></a> -->
                    </div>
                </form>
            </div>
        </div>

        <!-- 5.Dinding ------------------------------------------------------------------------------------------------------------------------------->
        <div role="tabpanel" class="tab-pane" id="dinding">
            <div class="container">
                <img width="500" src="<?= base_url('assets/img/dinding1.jpg') ?>">
                <form action="<?= base_url('C_Sekolah/terimaDataDinding') ?>" method="POST">

                    <div class="mt-4 Luas_A">
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas Total Dinding</label>
                            <input type="text" class="form-control" name="luas_total">
                        </div>
                    </div>



                    <!-- <div class="mt-4 tidak_rusak">
                        <ul>
                        
                            <li>Rangka Atap dalam kondisi baik
                            </li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas bidang yang rusak</label>
                            <input type="text" class="form-control" name="tidak_rusak">
                        </div>
                    </div> -->

                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class="mt-4 rusak_sangat_ringan">
                        <ul>
                            <li>Retak rambut dipermukaan dinding (lebar retakan < 0 2 mm)</li>
                            <li>Perubahan warna pada sebagian lapisan warna </li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas dinding yang rusak</label>
                            <input type="text" class="form-control" name="rusak_sangat_ringan">
                        </div>
                    </div>
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class="mt-4 rusak_ringan">
                        <ul>
                            <li>Retakan permukaan dinding terlihat jelas (lebar retakan
                                kira-kira 0.2mm - 1.0mm) </li>
                            <li>Perubahan pada lapisan cat meluas</li>


                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas dinding yang rusak</label>
                            <input type="text" class="form-control" name="rusak_ringan">
                        </div>
                    </div>
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class=" mt-4 rusak_sedang">
                        <ul>
                            <li>Dinding retakan meluas (lebar retakan kira-kira 1-2 mm)</li>
                            <li>Dinding partisi/penutup plafond terlepas</li>
                            <li>Plesteran retak sebagian dan lapisan cat terkelupas</li>
                            <li>Retakan besar pada dinding</li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas dinding yang rusak</label>
                            <input type="text" class="form-control" name="rusak_sedang">
                        </div>
                    </div>

                    <div class="rusak_berat">
                        <ul>
                            <li>Lapisan terkelupas meluas, berlumut dan plesteran
                                terkelupas meluas</li>


                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas dinding yang rusak</label>
                            <input type="text" class="form-control" name="rusak_berat">
                        </div>
                    </div>

                    <div class="rusak_sangat_berat">
                        <ul>
                            <li>Dinding runtuh</li>


                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas dinding yang rusak</label>
                            <input type="text" class="form-control" name="rusak_sangat_berat">
                        </div>
                    </div>

                    <div class="komponen_tidak_sesuai">
                        <ul>
                            <li>Material Dimensi dan kontruksi pondasi diindikasikan tidak sesuai dengan persyaratan teknis merujuk pada rencana teknis apabila ada petunjuk teknis dan/atau SNI</li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas dinding yang rusak</label>
                            <input type="text" class="form-control" name="komponen_tidak-sesuai">
                        </div>
                    </div>

                    <div class="mb-5">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <!-- <a href="#penutupatap" class="nav-link" role="tab" data-toggle="tab"></a> -->
                    </div>
                </form>
            </div>
        </div>

        <!-- 6.Plafond ------------------------------------------------------------------------------------------------------------------------------->
        <div role="tabpanel" class="tab-pane" id="plafond">
            <div class="container">
                <img width="500" src="<?= base_url('assets/img/3.jpg') ?>">
                <form action="<?= base_url('C_Sekolah/terimaDataPlafond') ?>" method="POST">

                    <div class="mt-4 panjang_a">
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">panjang "a"</label>
                            <input type="text" class="form-control" name="panjang_a">
                        </div>
                    </div>

                    <div class="mt-4 panjang_b">
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">panjang "b"</label>
                            <input type="text" class="form-control" name="panjang_b">
                        </div>
                    </div>

                    <div class="mt-4 panjang_c">
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">panjang "c"</label>
                            <input type="text" class="form-control" name="panjang_c">
                        </div>
                    </div>

                    <!-- <div class="mt-4 Luas_A">
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas Total Rangka Plafond Ruangan</label>
                            <input type="text" class="form-control" name="luas_total">
                        </div>
                    </div> -->



                    <!-- <div class="mt-4 tidak_rusak">
                        <ul>
                        
                            <li>Rangka Atap dalam kondisi baik
                            </li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas bidang yang rusak</label>
                            <input type="text" class="form-control" name="tidak_rusak">
                        </div>
                    </div> -->

                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class="mt-4 rusak_sangat_ringan">
                        <ul>
                            <li>Indikasi kelembabanatau kebocoran kecila atap dengan adanya bercak pada sebagian lapisan warna langit-langit atauu plafon</li>


                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas total rangka plafond yang rusak (Contoh: A + B)</label>
                            <input type="text" class="form-control" name="rusak_sangat_ringan">
                        </div>
                    </div>
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class="mt-4 rusak_ringan">
                        <ul>
                            <li>Terjadi indikasi kelembaban atau genangan air pada plafon meluas dengan bercak pada lapisan warna langit-langit meluas</li>



                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas total rangka plafond yang rusak (Contoh: A + B)</label>
                            <input type="text" class="form-control" name="rusak_ringan">
                        </div>
                    </div>
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class=" mt-4 rusak_sedang">
                        <ul>
                            <li>penutup bukan langit-langit terlepas</li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas total rangka plafond yang rusak (Contoh: A + B)</label>
                            <input type="text" class="form-control" name="rusak_sedang">
                        </div>
                    </div>

                    <div class="rusak_berat">
                        <ul>
                            <li> penutup langit-langit melendut sangat besar dengan kemungkinan keruntuhan besar
                            </li>


                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas total rangka plafond yang rusak (Contoh: A + B)</label>
                            <input type="text" class="form-control" name="rusak_berat">
                        </div>
                    </div>

                    <div class="rusak_sangat_berat">
                        <ul>
                            <li> Rangka langit-langit runtuh</li>


                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas total rangka plafond yang rusak (Contoh: A + B)</label>
                            <input type="text" class="form-control" name="rusak_sangat_berat">
                        </div>
                    </div>

                    <div class="komponen_tidak_sesuai">
                        <ul>
                            <li>Material Dimensi dan kontruksi pondasi diindikasikan tidak sesuai dengan persyaratan teknis merujuk pada rencana teknis apabila ada petunjuk teknis dan/atau SNI</li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas total rangka plafond yang rusak (Contoh: A + B)</label>
                            <input type="text" class="form-control" name="komponen_tidak-sesuai">
                        </div>
                    </div>

                    <div class="mb-5">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <!-- <a href="#penutupatap" class="nav-link" role="tab" data-toggle="tab"></a> -->
                    </div>
                </form>
            </div>
        </div>

        <!-- 7.Lantai ------------------------------------------------------------------------------------------------------------------------------->
        <div role="tabpanel" class="tab-pane" id="lantai">
            <div class="container">
                <!-- <img width="500" src="<?= base_url('assets/img/dinding1.jpg') ?>"> -->
                <form action="<?= base_url('C_Sekolah/terimaDataLantai') ?>" method="POST">

                    <div class="mt-4 Luas_Total_lantai">
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas Total Lantai</label>
                            <input type="text" class="form-control" name="luas_total">
                        </div>
                    </div>

                    <!-- <div class="mt-4 tidak_rusak">
                        <ul>
                        
                            <li>Rangka Atap dalam kondisi baik
                            </li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas bidang yang rusak</label>
                            <input type="text" class="form-control" name="tidak_rusak">
                        </div>
                    </div> -->

                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class="mt-4 rusak_sangat_ringan">
                        <ul>
                            <li>Penutup lantai gores</li>


                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas lantai yang rusak</label>
                            <input type="text" class="form-control" name="rusak_sangat_ringan">
                        </div>
                    </div>
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class="mt-4 rusak_ringan">
                        <ul>
                            <li>Penutup lantai retak/remuk sebagian </li>



                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas lantai yang rusak</label>
                            <input type="text" class="form-control" name="rusak_ringan">
                        </div>
                    </div>
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class=" mt-4 rusak_sedang">
                        <ul>
                            <li>Penutup lantai sebagian terlepas</li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas lantai yang rusak</label>
                            <input type="text" class="form-control" name="rusak_sedang">
                        </div>
                    </div>

                    <div class="rusak_berat">
                        <ul>
                            <li>Pentup lantai sebagian besar terlepas</li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas lantai yang rusak</label>
                            <input type="text" class="form-control" name="rusak_berat">
                        </div>
                    </div>

                    <div class="rusak_sangat_berat">
                        <ul>
                            <li>Lantai meledak, terlepas</li>


                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas lantai yang rusak</label>
                            <input type="text" class="form-control" name="rusak_sangat_berat">
                        </div>
                    </div>

                    <div class="komponen_tidak_sesuai">
                        <ul>
                            <li>Material Dimensi dan kontruksi pondasi diindikasikan tidak sesuai dengan persyaratan teknis merujuk pada rencana teknis apabila ada petunjuk teknis dan/atau SNI</li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas lantai yang rusak</label>
                            <input type="text" class="form-control" name="komponen_tidak-sesuai">
                        </div>
                    </div>

                    <div class="mb-5">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <!-- <a href="#penutupatap" class="nav-link" role="tab" data-toggle="tab"></a> -->
                    </div>
                </form>
            </div>
        </div>

        <!-- 8. Kusen ---------------------------------------------------------------------------------------------------------------------------------->
        <div role="tabpanel" class="tab-pane" id="kusen">
            <div class="container">
                <!-- <img width="500" src="<?= base_url('assets/img/balok1.jpg') ?>"> -->
                <form action="<?= base_url('C_Sekolah/terimaDataKusen') ?>" method="POST">

                    <div class="mt-4 jumlah_unit">
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah Total Kusen</label>
                            <input type="text" class="form-control" name="jumlah_unit">
                        </div>
                        <!-- <hr class="sidebar-divider my-0"> -->
                    </div>
                    <div class="mt-4 tidak_rusak">
                        <ul>
                            <!-- Deskripsi Kerusakan -->
                            <li>Kusen dalam kondisi baik</li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="tidak_rusak">
                        </div>
                    </div>
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class="mt-4 rusak_sangat_ringan">
                        <ul>
                            <li>Perubahan warna atau gores atau retak pada sebagian kusen</li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="rusak_sangat_ringan">
                        </div>
                    </div>
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class="mt-4 rusak_ringan">
                        <ul>
                            <li> Kayu terlihat lampu keropos pada sebagian kecil kusen </li>
                            <li> Aluminium atau iki visi sebagian kecil khusus yang terletak terletak dan gompal berlubang akibat benturan </li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="rusak_ringan">
                        </div>
                    </div>
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class=" mt-4 rusak_sedang">
                        <ul>
                            <li>Kayu terlihat Lapuk atau keropos dan berlubang semakin meluas adanya sambungan lepas</li>
                            <li>Aluminium atau upvc terlihat gombal atau berlubang terjadi di banyak bagian sambungan antara batang aluminium mulai terlihat lepas terjadi deformasi atau melengkung</li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="rusak_sedang">
                        </div>
                    </div>

                    <div class="rusak_berat">
                        <ul>
                            <li>Kayu terlihat Lapuk keropos dan berlubang pada sebagian besar kusen patah Pada sambungan kusen deformasi melengkung sehingga daun pintu atau jendela tidak dapat menutup </li>
                            <li>Aluminium yang terlihat Sambungan antar belakang batang aluminium terlepas deformasi melengkung semakin parah sehingga daun pintu atau jendela tidak dapat menutup terjadi pada atau sobek pada plat aluminium di bagian engsel</li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="rusak_berat">
                        </div>
                    </div>

                    <div class="rusak_sangat_berat">
                        <ul>
                            <li>Kusen tidak tidak berfungsi menahan daun pintu atau jendela akibat akumulasi kerusakan pada sebagian besar kusen</li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="rusak_sangat_berat">
                        </div>
                    </div>

                    <div class="komponen_tidak_sesuai">
                        <ul>
                            <li>Material Dimensi dan kontruksi pondasi diindikasikan tidak sesuai dengan persyaratan teknis merujuk pada rencana teknis apabila ada petunjuk teknis dan/atau SNI</li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="komponen_tidak-sesuai">
                        </div>
                    </div>

                    <div class="mb-5">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <!-- <a href="#penutupatap" class="nav-link" role="tab" data-toggle="tab"></a> -->
                    </div>
                </form>
            </div>
        </div>

        <!-- 9. Pintu ---------------------------------------------------------------------------------------------------------------------------------->
        <div role="tabpanel" class="tab-pane" id="pintu">
            <div class="container">
                <!-- <img width="500" src="<?= base_url('assets/img/balok1.jpg') ?>"> -->
                <form action="<?= base_url('C_Sekolah/terimaDataPintu') ?>" method="POST">

                    <div class="mt-4 jumlah_unit">
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah Total Pintu</label>
                            <input type="text" class="form-control" name="jumlah_unit">
                        </div>
                        <!-- <hr class="sidebar-divider my-0"> -->
                    </div>
                    <div class="mt-4 tidak_rusak">
                        <ul>
                            <!-- Deskripsi Kerusakan -->
                            <li>Pintu dalam kondisi baik</li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="tidak_rusak">
                        </div>
                    </div>
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class="mt-4 rusak_sangat_ringan">
                        <ul>
                            <li>Perubahan warna atau gores atau retak pada sebagian daun pintu</li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="rusak_sangat_ringan">
                        </div>
                    </div>
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class="mt-4 rusak_ringan">
                        <ul>
                            <li> Kayu terlihat Lapuk atau keropos pada sebagian kecil pintu </li>
                            <li> Aluminium atau upvc sebagai pintu terlihat retak dan gompal atau berlubang akibat benturan</li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="rusak_ringan">
                        </div>
                    </div>
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class=" mt-4 rusak_sedang">
                        <ul>
                            <li>Kayu terlihat Lapuk atau keropos atau berlubang pada semakin meluas dan kunci tidak berfungsi baik</li>
                            <li>Aluminium atau besi terlihat gompal atau berlubang terjadi di banyak bagian handal dan kunci tidak berfungsi baik</li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="rusak_sedang">
                        </div>
                    </div>

                    <div class="rusak_berat">
                        <ul>
                            <li>Kayu terlihat rangka pintu patah atau sambungan terlepas multiplek penutup pintu terlepas atau berlubang hendel dan kunci tidak ada </li>
                            <li>Auminium atau divisi terlihat rangka atau lapisan daun pintu patah atau lepas sambungan handle dan kunci tidak ada</li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="rusak_berat">
                        </div>
                    </div>

                    <div class="rusak_sangat_berat">
                        <ul>
                            <li>Daun pintu dalam kondisi tidak berfungsi atau berlubang besar atau tidak dapat menutup atau dilepaskan akibat akumulasi kerusakan pada sebagian besar bagian-bagiannya</li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="rusak_sangat_berat">
                        </div>
                    </div>

                    <div class="komponen_tidak_sesuai">
                        <ul>
                            <li>Material Dimensi dan kontruksi pondasi diindikasikan tidak sesuai dengan persyaratan teknis merujuk pada rencana teknis apabila ada petunjuk teknis dan/atau SNI</li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="komponen_tidak-sesuai">
                        </div>
                    </div>

                    <div class="mb-5">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <!-- <a href="#penutupatap" class="nav-link" role="tab" data-toggle="tab"></a> -->
                    </div>
                </form>
            </div>
        </div>

        <!-- 10. Jendela ---------------------------------------------------------------------------------------------------------------------------------->
        <div role="tabpanel" class="tab-pane" id="jendela">
            <div class="container">
                <!-- <img width="500" src="<?= base_url('assets/img/balok1.jpg') ?>"> -->
                <form action="<?= base_url('C_Sekolah/terimaDataJendela') ?>" method="POST">

                    <div class="mt-4 jumlah_unit">
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah Total Jendela</label>
                            <input type="text" class="form-control" name="jumlah_unit">
                        </div>
                        <!-- <hr class="sidebar-divider my-0"> -->
                    </div>
                    <div class="mt-4 tidak_rusak">
                        <ul>
                            <!-- Deskripsi Kerusakan -->
                            <li>Jendela dalam kondisi baik</li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="tidak_rusak">
                        </div>
                    </div>
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class="mt-4 rusak_sangat_ringan">
                        <ul>
                            <li>Perubahan warna pada sebagian lapisan rangka daun jendela</li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="rusak_sangat_ringan">
                        </div>
                    </div>
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class="mt-4 rusak_ringan">
                        <ul>
                            <li> Terlihat Lapuk atau keropos atau retak atau gompal akibat benturan pada bingkai jendela </li>
                            <li>Terlihat terletak pada sebagian kecil kaca</li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="rusak_ringan">
                        </div>
                    </div>
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class=" mt-4 rusak_sedang">
                        <ul>
                            <li>Terlihat Lapuk atau keropos atau retak atau gompal semakin meluas engsel dan kunci tidak berfungsi baik sehingga jendela tidak dapat menutup sempurna </li>
                            <li>Terlihat retak lebar pada kaca</li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="rusak_sedang">
                        </div>
                    </div>

                    <div class="rusak_berat">
                        <ul>
                            <li>Terlihat pada bingkai jendela terjadi deformasi atau melengkung atau lepas sambungan sehingga jendela sulit dibuka </li>
                            <li>Terlihat pecah pada kaca</li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="rusak_berat">
                        </div>
                    </div>

                    <div class="rusak_sangat_berat">
                        <ul>
                            <li>Terlihat pada bingkai j jendela semakin parah atau terjadi patah sehingga jendela tidak dapat dibuka sama sekali</li>
                            <li>Terlihat pecahan secara menyeluruh pada kaca</li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="rusak_sangat_berat">
                        </div>
                    </div>

                    <div class="komponen_tidak_sesuai">
                        <ul>
                            <li>Material Dimensi dan kontruksi pondasi diindikasikan tidak sesuai dengan persyaratan teknis merujuk pada rencana teknis apabila ada petunjuk teknis dan/atau SNI</li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="komponen_tidak-sesuai">
                        </div>
                    </div>

                    <div class="mb-5">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <!-- <a href="#penutupatap" class="nav-link" role="tab" data-toggle="tab"></a> -->
                    </div>
                </form>
            </div>
        </div>


        <!-- 11. Finishing Plafond ---------------------------------------------------------------------------------------------------------------------------------->
        <div role="tabpanel" class="tab-pane" id="fplafond">
            <div class="container">
                <!-- <img width="500" src="<?= base_url('assets/img/balok1.jpg') ?>"> -->
                <form action="<?= base_url('C_Sekolah/terimaDataFinishingPlafond') ?>" method="POST">

                    <div class="mt-4 jumlah_unit">
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas Total Finishing Plafond (Cat Lapisan Langit-langit)</label>
                            <input type="text" class="form-control" name="luas_total">
                        </div>
                        <!-- <hr class="sidebar-divider my-0"> -->
                    </div>

                    <!-- <div class="mt-4 tidak_rusak">
                        <ul>
                            <li>Jendela dalam kondisi baik</li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="tidak_rusak">
                        </div>
                    </div> -->
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class="mt-4 rusak_sangat_ringan">
                        <ul>
                            <li>Perubahan warna pada sebagian lapisan warna finishing plafon
                            </li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas lapisan finishing</label>
                            <input type="text" class="form-control" name="rusak_sangat_ringan">
                        </div>
                    </div>
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class="mt-4 rusak_ringan">
                        <ul>
                            <li> Perubahan warna pada lapisan cat plafon semakin meluas</li>


                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas lapisan finishing</label>
                            <input type="text" class="form-control" name="rusak_ringan">
                        </div>
                    </div>
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class=" mt-4 rusak_sedang">
                        <ul>
                            <li> Terlihat retak pada sebagian sambungan plafon </li>
                            <li>Lapisan cat plafon terkelupas sebagian</li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas lapisan finishing</label>
                            <input type="text" class="form-control" name="rusak_sedang">
                        </div>
                    </div>

                    <div class="rusak_berat">
                        <ul>
                            <li>Letak Pada sambungan plafon semakin meluas</li>
                            <li>Lapisan cat plafon terlihat terkelupas meluas dan berlumut</li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas lapisan finishing</label>
                            <input type="text" class="form-control" name="rusak_berat">
                        </div>
                    </div>

                    <div class="rusak_sangat_berat">
                        <ul>
                            <li>Retak Pada sambungan plafon terjadi hampir di seluruh bagian </li>
                            <li>Lapisan cat plafon terkelupas dan berlumut hampir di seluruh bagian</li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas lapisan finishing</label>
                            <input type="text" class="form-control" name="rusak_sangat_berat">
                        </div>
                    </div>

                    <div class="komponen_tidak_sesuai">
                        <ul>
                            <li>Material Dimensi dan kontruksi pondasi diindikasikan tidak sesuai dengan persyaratan teknis merujuk pada rencana teknis apabila ada petunjuk teknis dan/atau SNI</li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas lapisan finishing</label>
                            <input type="text" class="form-control" name="komponen_tidak-sesuai">
                        </div>
                    </div>

                    <div class="mb-5">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <!-- <a href="#penutupatap" class="nav-link" role="tab" data-toggle="tab"></a> -->
                    </div>
                </form>
            </div>
        </div>

        <!-- 12. Finishing Dinding ---------------------------------------------------------------------------------------------------------------------------------->
        <div role="tabpanel" class="tab-pane" id="fdinding">
            <div class="container">
                <!-- <img width="500" src="<?= base_url('assets/img/balok1.jpg') ?>"> -->
                <form action="<?= base_url('C_Sekolah/terimaDataFinishingDinding') ?>" method="POST">

                    <div class="mt-4 jumlah_unit">
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas Total Finishing Dinding</label>
                            <input type="text" class="form-control" name="luas_total">
                        </div>
                        <!-- <hr class="sidebar-divider my-0"> -->
                    </div>

                    <!-- <div class="mt-4 tidak_rusak">
                        <ul>
                            <li>Jendela dalam kondisi baik</li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="tidak_rusak">
                        </div>
                    </div> -->
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class="mt-4 rusak_sangat_ringan">
                        <ul>
                            <li>Perubahan warna pada sebagian lapisan warna finishing dinding
                            </li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas lapisan finishing</label>
                            <input type="text" class="form-control" name="rusak_sangat_ringan">
                        </div>
                    </div>
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class="mt-4 rusak_ringan">
                        <ul>
                            <li> Perubahan warna pada lapisan cat dinding semakin meluas

                            </li>


                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas lapisan finishing</label>
                            <input type="text" class="form-control" name="rusak_ringan">
                        </div>
                    </div>
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class=" mt-4 rusak_sedang">
                        <ul>
                            <li>Terlihat retak pada sebagian sambungan </li>
                            <li> Lapisan cat terkelupas sebagian</li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas lapisan finishing</label>
                            <input type="text" class="form-control" name="rusak_sedang">
                        </div>
                    </div>

                    <div class="rusak_berat">
                        <ul>
                            <li>Plesteran terkelupas meluas</li>
                            <li>Lapisan cat terkelupas meluas dan berlumut</li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas lapisan finishing</label>
                            <input type="text" class="form-control" name="rusak_berat">
                        </div>
                    </div>

                    <div class="rusak_sangat_berat">
                        <ul>
                            <li>Plesteran dan lapisan cat terkelupas hampir diseluruh bagian</li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas lapisan finishing</label>
                            <input type="text" class="form-control" name="rusak_sangat_berat">
                        </div>
                    </div>

                    <div class="komponen_tidak_sesuai">
                        <ul>
                            <li>Material Dimensi dan kontruksi pondasi diindikasikan tidak sesuai dengan persyaratan teknis merujuk pada rencana teknis apabila ada petunjuk teknis dan/atau SNI</li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas lapisan finishing</label>
                            <input type="text" class="form-control" name="komponen_tidak-sesuai">
                        </div>
                    </div>

                    <div class="mb-5">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <!-- <a href="#penutupatap" class="nav-link" role="tab" data-toggle="tab"></a> -->
                    </div>
                </form>
            </div>
        </div>

        <!-- 13. Finishing Kusen ---------------------------------------------------------------------------------------------------------------------------------->
        <div role="tabpanel" class="tab-pane" id="fkusen">
            <div class="container">
                <!-- <img width="500" src="<?= base_url('assets/img/balok1.jpg') ?>"> -->
                <form action="<?= base_url('C_Sekolah/terimaDataFinishingKusen') ?>" method="POST">

                    <div class="mt-4 jumlah_unit">
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas Total Finishing Kusen</label>
                            <input type="text" class="form-control" name="luas_total">
                        </div>
                        <!-- <hr class="sidebar-divider my-0"> -->
                    </div>

                    <!-- <div class="mt-4 tidak_rusak">
                        <ul>
                            <li>Jendela dalam kondisi baik</li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Jumlah</label>
                            <input type="text" class="form-control" name="tidak_rusak">
                        </div>
                    </div> -->
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class="mt-4 rusak_sangat_ringan">
                        <ul>
                            <li>Perubahan warna pada sebagian lapisan warna finishing kusen</li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas lapisan finishing</label>
                            <input type="text" class="form-control" name="rusak_sangat_ringan">
                        </div>
                    </div>
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class="mt-4 rusak_ringan">
                        <ul>
                            <li> Perubahan warna pada lapisan cat kusen semakin meluas </li>


                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas lapisan finishing</label>
                            <input type="text" class="form-control" name="rusak_ringan">
                        </div>
                    </div>
                    <!-- <hr class="sidebar-divider my-0"> -->

                    <div class=" mt-4 rusak_sedang">
                        <ul>
                            <li>Lapisan cat kusen dan pintu terkelupas sebagian </li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas lapisan finishing</label>
                            <input type="text" class="form-control" name="rusak_sedang">
                        </div>
                    </div>

                    <div class="rusak_berat">
                        <ul>
                            <li>Lapisan cat kusen dan pintu terlihat terkelupas meluas

                            </li>
                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas lapisan finishing</label>
                            <input type="text" class="form-control" name="rusak_berat">
                        </div>
                    </div>

                    <div class="rusak_sangat_berat">
                        <ul>
                            <li>Lapisan cat kusen dan pintu ntar kalau pas hampir di seluruh bagian</li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas lapisan finishing</label>
                            <input type="text" class="form-control" name="rusak_sangat_berat">
                        </div>
                    </div>

                    <div class="komponen_tidak_sesuai">
                        <ul>
                            <li>Material Dimensi dan kontruksi pondasi diindikasikan tidak sesuai dengan persyaratan teknis merujuk pada rencana teknis apabila ada petunjuk teknis dan/atau SNI</li>

                        </ul>
                        <div class="mb-3">
                            <label for="formGroupExampleInput" class="form-label">Luas lapisan finishing</label>
                            <input type="text" class="form-control" name="komponen_tidak-sesuai">
                        </div>
                    </div>

                    <div class="mb-5">
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <!-- <a href="#penutupatap" class="nav-link" role="tab" data-toggle="tab"></a> -->
                    </div>
                </form>
            </div>
        </div>

        <!-- 14. Instalasi Listrik ---------------------------------------------------------------------------------------------------------------------------------->
        <div role="tabpanel" class="tab-pane" id="instalasilistrik">
            <div class="container">
                <!-- <img width="500" src="<?= base_url('assets/img/balok1.jpg') ?>"> -->
                <form action="<?= base_url('C_Sekolah/terimaDataInstalasiListrik') ?>" method="POST">
                    <form>
                        <div class="mb-3 form-check">
                            <input type="radio" value="0" class="form-check-input" name="listrik">
                            <label class="form-check-label" for="exampleCheck1"> jaringan listrik dalam kondisi baik
                            </label>
                        </div>

                        <div class="mb-3 form-check">
                            <input type="radio" value="0.2" class="form-check-input" name="listrik">
                            <label class="form-check-label" for="exampleCheck1">
                                • Sebagian kecil komponen dari panel-panel LP rusak, ada
                                • Sedikit jalur kabel instalasi shortage, sebagian kecil
                                • Armatur rusak ringan, sehingga biaya perbaikan kurang
                                dari 5% dari biaya instalasi baru

                            </label>
                        </div>

                        <div class="mb-3 form-check">
                            <input type="radio" value="0.35" class="form-check-input" name="listrik">
                            <label class="form-check-label" for="exampleCheck1"> • Beberapa komponen dari panel-panel LP rusak, sebagian kecil jalur kabel instalasi shortage, sehingga armatur rusak ringan, sehingga biaya perbaikan 5-20% dari biaya instalasi baru penurunan tidak melebihi 1/250 L
                            </label>
                        </div>

                        <div class="mb-3 form-check">
                            <input type="radio" value="0.5" class="form-check-input" name="listrik">
                            <label class="form-check-label" for="exampleCheck1"> • Beberapa komponen dari panel-panel LP rusak, sebagian kecil jalur kabel instalasi shortage, sehingga armatur rusak berat dan ringan, sehingga biaya perbaikan 20-50% dari biaya instalasi baru

                            </label>
                        </div>

                        <div class="mb-3 form-check">
                            <input type="radio" value="0.7" class="form-check-input" name="listrik">
                            <label class="form-check-label" for="exampleCheck1"> • Sebagian besar komponen panel-panel LP rusak, sebagian besar kabel instalasi shortage, sebagian besar armatur rusak, sehingga biaya perbaikan lebih dari 50-65% dari instalasi baru
                            </label>
                        </div>

                        <div class="mb-3 form-check">
                            <input type="radio" value="0.85" class="form-check-input" name="listrik">
                            <label class="form-check-label" for="exampleCheck1"> • Sebagian besar komponen panel-panel LP rusak, sebagian besar kabel instalasi shortage, seluruh armatur rusak, sehingga biaya perbaikan lebih dari 65% dari instalasi baru
                            </label>
                        </div>

                        <div class="mb-3 form-check">
                            <input type="radio" value="1" class="form-check-input" name="listrik">
                            <label class="form-check-label" for="exampleCheck1">Material Dimensi dan kontruksi pondasi diindikasikan tidak sesuai dengan persyaratan teknis merujuk pada rencana teknis apabila ada petunjuk teknis dan/atau SNI</label>
                        </div>


                        <button type="submit" class="btn btn-primary">Submit</button>


                    </form>
                </form>
            </div>
        </div>

        <!-- 15. Instalasi Air ---------------------------------------------------------------------------------------------------------------------------------->
        <div role="tabpanel" class="tab-pane" id="instalasiair">
            <div class="container">
                <!-- <img width="500" src="<?= base_url('assets/img/balok1.jpg') ?>"> -->
                <form action="<?= base_url('C_Sekolah/terimaDataInstalasiAir') ?>" method="POST">
                    <form>
                        <div class="mb-3 form-check">
                            <input type="radio" value="0" class="form-check-input" name="air">
                            <label class="form-check-label" for="exampleCheck1">Sistem penyedian air dalam kondisi baik </label>
                        </div>

                        <div class="mb-3 form-check">
                            <input type="radio" value="0.2" class="form-check-input" name="air">
                            <label class="form-check-label" for="exampleCheck1">• Kebocoran pipa terbatas ditempat yang terlihat atau mudah dicapai, keran keran kecil rusak, sehingga biaya perbaikan kurang dari 1% biaya instalasi baru

                            </label>
                        </div>

                        <div class="mb-3 form-check">
                            <input type="radio" value="0.35" class="form-check-input" name="air">
                            <label class="form-check-label" for="exampleCheck1">• Bagian bagian kecil pemipaan bocor, motor pompa terbakar, keran-keran kecil rusak, sehingga biaya perbaikan antara 1-10% dari biaya instalasi baru. </label>
                        </div>

                        <div class="mb-3 form-check">
                            <input type="radio" value="0.5" class="form-check-input" name="air">
                            <label class="form-check-label" for="exampleCheck1"> • Pompa, motor, pipa, dan keran rusak apabila diganti atau diperbaiki memerlukan biaya antara 10-25% dari biaya instalasi baru.
                            </label>
                        </div>

                        <div class="mb-3 form-check">
                            <input type="radio" value="0.7" class="form-check-input" name="air">
                            <label class="form-check-label" for="exampleCheck1">• Sebagian besar pompa, sebagian besar motor terbakar, pipa utama bocor namun ditempat terbuka, beberapa keran tidak befungsi, sehingga biaya perbaikan 25-50% dari biaya instalasi baru </label>
                        </div>

                        <div class="mb-3 form-check">
                            <input type="radio" value="0.85" class="form-check-input" name="air">
                            <label class="form-check-label" for="exampleCheck1"> • Pompa-pompa rusak total, motor terbakar, dibanyak tempat terbuka dan tutup pipa pipa bocor, keran keran tidak berfungsi, sehingga perbaikan instalasi perlu menyeluruh, dengan perkiraan biaya lebih dari 50% dari
                                biaya instalasi baru. </label>
                        </div>

                        <div class="mb-3 form-check">
                            <input type="radio" value="1" class="form-check-input" name="air">
                            <label class="form-check-label" for="exampleCheck1">Material Dimensi dan kontruksi pondasi diindikasikan tidak sesuai dengan persyaratan teknis merujuk pada rencana teknis apabila ada petunjuk teknis dan/atau SNI</label>
                        </div>


                        <button type="submit" class="btn btn-primary">Submit</button>


                    </form>
                </form>
            </div>
        </div>



    </div><!-- Penutup Semua tiap konten-->
</div><!-- Penutup paling atas -->










<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script src="https://cdn.rawgit.com/twbs/bootstrap/v4-dev/dist/js/bootstrap.js"></script>