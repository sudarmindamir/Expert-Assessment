<div class="container mt-5">
    <div class="row">
        <div class="col-md-12">
            <table id="example" class="table table-striped table-bordered" style="width:100%">
                <tr>
                    <th scope="row">1</th>
                    <td>Pondasi dan Sloof</td>
                    <td>Pondasi dan Sloof</td>
                    <td class="text-center">
                        <a href="" class="btn btn-primary">Detail</a>
                        <a href="" class="btn btn-danger">Edit</a>
                    </td>
                </tr>

                <tr>
                    <th scope="row">2</th>
                    <td>Kolom</td>
                    <td>Kolom</td>
                    <td class="text-center">
                        <?php if (!empty($kolom)) { ?>
                            <a href="" class="btn btn-primary">Detail</a>
                            <a href="" class="btn btn-danger">Edit</a>
                        <?php } else { ?>
                            <p>Kolom belum diinput</p>
                            <a href="" class="btn btn-success">Input Sekarang</a>
                        <?php } ?>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</div>