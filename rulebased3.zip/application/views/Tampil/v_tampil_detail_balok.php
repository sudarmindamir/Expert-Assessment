<table border="1">
    <thead>
        <tr>
            <td>id balok</td>
            <td>Jumlah Unit</td>
            <td>Tidak Rusak</td>
            <td>Rusak Sangat Ringan</td>
            <td>Rusak Ringan</td>
            <td>Rusak Sedang</td>
            <td>Rusak Berat</td>
            <td>Rusak Sangat Berat</td>
            <td>Komponen Tidak Sesuai</td>
            <td>Total Kerusakan Balok</td>
            <td>Tingkat Kerusakan Balok</td>


        </tr>
    </thead>
    <tbody>
        <tr>
            <td><?= $balok->id_balok; ?></td>
            <td><?= $balok->jumlah_unit; ?></td>
            <td><?= $balok->tidak_rusak; ?></td>
            <td><?= $balok->rusak_sangat_ringan; ?></td>
            <td><?= $balok->rusak_ringan; ?></td>
            <td><?= $balok->rusak_sedang; ?></td>
            <td><?= $balok->rusak_berat; ?></td>
            <td><?= $balok->rusak_sangat_berat; ?></td>
            <td><?= $balok->komponen_tidak_sesuai; ?></td>
            <td><?= $balok->total_kerusakan_balok; ?></td>
            <td><?= $balok->tingkat_kerusakan_balok; ?></td>

            <!-- $pondasiini didapat dari nama variabel array yang ada di controllernya liat yg di bawah -->
            <!-- $data['pondasiini'] = $this->M_Tampil->tampil_detail_pondasi($where); -->


            <td> <a href="<?= base_url('C_Tampil/tampil_balok/') . $balok->id_balok ?>">Kembali</a></td>


        </tr>
    </tbody>
</table>